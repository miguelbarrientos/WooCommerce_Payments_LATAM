import ErrorHandler from './modules/ErrorHandler';
import Spinner from "./modules/Helper/Spinner";

($ => {

    let errorHandler = null;
    let spinner = null;

    let render = () => {
        if ($( "#ppc-button-cc" ).length) {
            let cc_button = paypal.Buttons({
                fundingSource: paypal.FUNDING.CARD,
                style: {
                    // color: 'black',
                    shape: PayPalCommerceGateway.button.style.shape
                },
                createOrder: function(data, actions) {
                    const formValues = $("form.checkout").serialize();
                    spinner.block();
                    return fetch(PayPalCommerceGateway.ajax.create_order.endpoint, {
                        method: "POST",
                        body: JSON.stringify({
                            nonce: PayPalCommerceGateway.ajax.create_order.nonce,
                            payer: {
                                email_address: $("form.checkout #billing_email").val(),
                                // phone: $("form.checkout #billing_phone").val()
                                phone: {
                                    phone_number: {
                                        national_number: $("form.checkout #billing_phone").val()
                                    },
                                    phone_type: "HOME"
                                }
                            },
                            bn_code:PayPalCommerceGateway.bn_codes.checkout,
                            context:PayPalCommerceGateway.context,
                            order_id:PayPalCommerceGateway.order_id,
                            payment_method: 'ppcp-cc-gateway',
                            form:formValues
                        })
                    }).then(function (res) {
                        return res.json();
                    }).then(function (data) {
                        spinner.unblock();
                        if (!data.success) {
                            errorHandler.message(data.data.message, true);
                            return;
                        }
                        const input = document.createElement("input");
                        input.setAttribute("type", "hidden");
                        input.setAttribute("name", "ppcp-resume-order");
                        input.setAttribute("value", data.data.purchase_units[0].custom_id);
                        document.querySelector("form.checkout").append(input);
                        return data.data.id;
                    });
                },
                onApprove: function(data, actions) {
                    spinner.block();
                    return fetch(PayPalCommerceGateway.ajax.approve_order.endpoint, {
                        method: "POST",
                        body: JSON.stringify({
                            nonce: PayPalCommerceGateway.ajax.approve_order.nonce,
                            order_id:
                            data.orderID
                        })
                    }).then((res)=>{
                        return res.json();
                    }).then((data)=>{
                        spinner.unblock();
                        if (!data.success) {
                            if (data.data.code === 100) {
                                errorHandler.message(data.data.message);
                            } else {
                                errorHandler.genericError();
                            }
                            if (typeof actions !== "undefined" && typeof actions.restart !== "undefined") {
                                return actions.restart();
                            }
                            throw new Error(data.data.message);
                        }
                        document.querySelector("#place_order").click()
                    });
                },
                onCancel: () => {
                    spinner.unblock();
                },
                onError: () => {
                    errorHandler.genericError();
                    spinner.unblock();
                }
            });

            if (cc_button.isEligible()) {
                errorHandler = new ErrorHandler(PayPalCommerceGateway.labels.error.generic);
                spinner = new Spinner();
                $("#ppc-button-cc").empty();
                cc_button.render("#ppc-button-cc");
                if ($("#payment_method_ppcp-cc-gateway").is(":checked")) {
                    setTimeout(() => toggleButtons('ppcp-cc-gateway'), 500);
                }
            }
        }
    }

    let toggleButtons = (value) => {
        if(value === "ppcp-cc-gateway") {
            $("#place_order").hide();
            $("#ppc-button").hide();
            $("#ppc-button-cc").show();
        } else {
            $("#ppc-button-cc:visible").hide();
        }
    }

    $(document).on("change", ".wc_payment_method input", function(){
        toggleButtons(this.value);
    });

    // $(document).ready(() => $(document.body).on('updated_checkout', tmp));
    $(document).ready(() => $(document.body).on('updated_checkout', render));

})(jQuery);