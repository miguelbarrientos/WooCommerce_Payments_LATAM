<?php
/**
 * Endpoint to verify if an order has been approved. An approved order
 * will be stored in the current session.
 *
 * @package WooCommerce\PayPalCommerce\Button\Endpoint
 */

declare(strict_types=1);

namespace WooCommerce\PayPalCommerce\Button\Endpoint;

use WooCommerce\PayPalCommerce\ApiClient\Endpoint\OrderEndpoint;
use WooCommerce\PayPalCommerce\ApiClient\Entity\OrderStatus;
use WooCommerce\PayPalCommerce\ApiClient\Exception\PayPalApiException;
use WooCommerce\PayPalCommerce\Button\Exception\RuntimeException;
use WooCommerce\PayPalCommerce\Session\SessionHandler;
use WooCommerce\PayPalCommerce\WcGateway\Settings\Settings;

/**
 * Class ConfirmPaymentSourceOrderEndpoint
 */
class ConfirmPaymentSourceOrderEndpoint implements EndpointInterface {


	const ENDPOINT = 'ppc-confirm-payment-source-order';

	/**
	 * The request data helper.
	 *
	 * @var RequestData
	 */
	private $request_data;

	/**
	 * The session handler.
	 *
	 * @var SessionHandler
	 */
	private $session_handler;

	/**
	 * The order endpoint.
	 *
	 * @var OrderEndpoint
	 */
	private $api_endpoint;

	/**
	 * The settings.
	 *
	 * @var Settings
	 */
	private $settings;


	/**
	 * ConfirmPaymentSourceOrderEndpoint constructor.
	 *
	 * @param RequestData    $request_data The request data helper.
	 * @param OrderEndpoint  $order_endpoint The order endpoint.
	 * @param SessionHandler $session_handler The session handler.
	 * @param Settings       $settings The settings.
	 */
	public function __construct(
		RequestData $request_data,
		OrderEndpoint $order_endpoint,
		SessionHandler $session_handler,
		Settings $settings
	) {

		$this->request_data    = $request_data;
		$this->api_endpoint    = $order_endpoint;
		$this->session_handler = $session_handler;
		$this->settings        = $settings;
	}

	/**
	 * The nonce.
	 *
	 * @return string
	 */
	public static function nonce(): string {
		return self::ENDPOINT;
	}

	/**
	 * Handles the request.
	 *
	 * @return bool
	 * @throws RuntimeException When no order was found.
	 */
	public function handle_request(): bool {
		try {
			$data = $this->request_data->read_request( $this->nonce() );
			if ( ! isset( $data['order_id'] ) ) {
				throw new RuntimeException(
					__( 'No order id given', 'woocommerce-paypal-payments-mx' )
				);
			}

			$order = $this->api_endpoint->order( $data['order_id'] );
			if ( ! $order ) {
				throw new RuntimeException(
					sprintf(
						// translators: %s is the id of the order.
						__( 'Order %s not found.', 'woocommerce-paypal-payments-mx' ),
						$data['order_id']
					)
				);
			}

			if ( ! $order->status()->is( OrderStatus::COMPLETED ) ) {
				throw new RuntimeException(
					sprintf(
					// translators: %s is the id of the order.
						__( 'Order %s is not completed yet.', 'woocommerce-paypal-payments-mx' ),
						$data['order_id']
					)
				);
			}

			$this->session_handler->replace_order( $order );
			wp_send_json_success( $order );
			return true;
		} catch ( \RuntimeException $error ) {
			wp_send_json_error(
				array(
					'name'    => is_a( $error, PayPalApiException::class ) ? $error->name() : '',
					'message' => $error->getMessage(),
					'code'    => $error->getCode(),
					'details' => is_a( $error, PayPalApiException::class ) ? $error->details() : array(),
				)
			);
			return false;
		}
	}
}
