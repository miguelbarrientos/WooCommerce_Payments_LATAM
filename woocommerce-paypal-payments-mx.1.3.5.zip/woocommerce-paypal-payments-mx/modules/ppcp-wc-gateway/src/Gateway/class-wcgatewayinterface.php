<?php
/**
 * The WcGateway interface.
 *
 * @package WooCommerce\PayPalCommerce\WcGateway\Gateway
 */

declare(strict_types=1);

namespace WooCommerce\PayPalCommerce\WcGateway\Gateway;

/**
 * Interface WcGatewayInterface
 */
interface WcGatewayInterface {


}
