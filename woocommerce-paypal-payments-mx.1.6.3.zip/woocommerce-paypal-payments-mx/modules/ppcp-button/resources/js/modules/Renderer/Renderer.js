class Renderer {
    constructor(creditCardRenderer, defaultConfig) {
        this.defaultConfig = defaultConfig;
        this.creditCardRenderer = creditCardRenderer;
    }

    render(wrapper, hostedFieldsWrapper, contextConfig, cc_wrapper = null) {
        if (PayPalCommerceGateway.button.disable_funding.includes(paypal.FUNDING.CARD)){
            this.renderCCButton();
        }
        this.renderButtons(wrapper, contextConfig, cc_wrapper);
        this.creditCardRenderer.render(hostedFieldsWrapper, contextConfig);
    }

    renderButtons(wrapper, contextConfig, cc_wrapper) {
        if (! document.querySelector(wrapper) || this.isAlreadyRendered(wrapper) || 'undefined' === typeof paypal.Buttons ) {
            return;
        }

        let style = wrapper === this.defaultConfig.button.wrapper ? this.defaultConfig.button.style : this.defaultConfig.button.mini_cart_style;

        Object.values(paypal.FUNDING).forEach(function(fundingSource){
            if (fundingSource !== paypal.FUNDING.PAYPAL){
                delete style.color;
            }
            let pp_button = paypal.Buttons({
                style,
                fundingSource: fundingSource,
                ...contextConfig,
            });

            if (pp_button.isEligible()) {
                pp_button.render(
                    paypal.FUNDING.CARD === fundingSource &&
                    PayPalCommerceGateway.button.disable_funding.includes(fundingSource) ?
                    cc_wrapper : wrapper
                );
            }
        });
    }

    isAlreadyRendered(wrapper) {
        return document.querySelector(wrapper).hasChildNodes();
    }

    hideButtons(element) {
        const domElement = document.querySelector(element);
        if (! domElement ) {
            return false;
        }
        domElement.style.display = 'none';
        return true;
    }

    showButtons(element) {
        const domElement = document.querySelector(element);
        if (! domElement ) {
            return false;
        }
        domElement.style.display = 'block';
        return true;
    }

    disableCreditCardFields() {
        this.creditCardRenderer.disableFields();
    }

    enableCreditCardFields() {
        this.creditCardRenderer.enableFields();
    }

    renderCCButton() {
        let button = document.querySelector(".payment_method_ppcp-gateway");
        let cc_id = "payment_method_ppcp-cc-gateway";
        if (button && !document.querySelector("." + cc_id)) {
            let ppcp_button = button.cloneNode(true);
            ppcp_button.classList.remove("payment_method_ppcp-gateway");
            ppcp_button.classList.add(cc_id);

            let input = ppcp_button.querySelector("input");
            input.id = cc_id;
            input.value = "ppcp-cc-gateway";
            input.checked = false;
            input.removeAttribute("checked");

            let label = ppcp_button.querySelector("label");
            label.setAttribute("for", cc_id);
            label.textContent = PayPalCommerceGateway.button.cc_title;

            ppcp_button.querySelector(".payment_box").remove();

            button.parentNode.insertBefore(ppcp_button, button);
        }
    }
}

export default Renderer;
