const onApprove = (context, errorHandler, spinner) => {
    return (data, actions) => {
        spinner.block();
        return fetch(context.config.ajax.approve_order.endpoint, {
            method: 'POST',
            body: JSON.stringify({
                nonce: context.config.ajax.approve_order.nonce,
                order_id:data.orderID
            })
        }).then((res)=>{
            return res.json();
        }).then((data)=>{
            spinner.unblock();
            if (!data.success) {
                if (data.data.code === 100) {
                    errorHandler.message(data.data.message);
                } else {
                    errorHandler.genericError();
                }
                if (typeof actions !== 'undefined' && typeof actions.restart !== 'undefined') {
                    return actions.restart();
                }
                throw new Error(data.data.message);
            }

            console.log("ForPayNow");
            document.getElementById("payment_method_ppcp-gateway").checked = true;
            console.log("payment_method_ppcp-gateway", document.getElementById("payment_method_ppcp-gateway").checked, "payment_method_ppcp-cc-gateway", document.getElementById("payment_method_ppcp-cc-gateway").checked);
            document.querySelector('#place_order').click()
        });

    }
}

export default onApprove;
