<?php
/**
 * The logging extensions.
 *
 * @package WooCommerce\WooCommerce\Logging
 */

declare(strict_types=1);


namespace WooCommerce\PayPalCommerce\Logging;

return array();
