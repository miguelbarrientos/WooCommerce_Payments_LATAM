<?php
/**
 * The button module extensions.
 *
 * @package WooCommerce\PayPalCommerce\Button
 */

declare(strict_types=1);

return array();
